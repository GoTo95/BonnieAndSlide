from setuptools import setup, find_packages

setup(
    name='BonnieAndSlide',
    url='https://github.com/GoTo95/BonnieAndSlide',
    packages=find_packages(),
    version='1.0'
)