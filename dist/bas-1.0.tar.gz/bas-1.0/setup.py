from setuptools import setup, find_packages

setup(
    name='bas',
    url='https://github.com/GoTo95/BonnieAndSlide',
    packages=find_packages(),
    version='1.0'
)