from Bonnieandslide import print_hi

print_hi('test')