from setuptools import setup

setup(
    # Needed to silence warnings (and to be a worthwhile package)
    name='Bonnieandslide',
    url='https://github.com/GoTo95/BonnieAndSlide',
    # *strongly* suggested for sharing
    version='0.1',
    # The license can be anything you like
    license='MIT'
)